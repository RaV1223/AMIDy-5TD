package com.example.demo1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class HelloApplication extends Application {

    private static final String API_KEY = "031385ed6f42c8b94f69a48a33544b84";
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/weather";
    private BorderPane borderPane;
    private TextField cityTextField;
    private Button searchButton;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("API Pogody");

        borderPane = new BorderPane();
        borderPane.setStyle("-fx-background-color: lightblue;");

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        vbox.setFillWidth(true);

        Label headerLabel = new Label("Twoja pogoda na dziś");
        headerLabel.setStyle("font-size: 20px; font-weight: bold;");

        cityTextField = new TextField();
        cityTextField.setPromptText("Wpisz nazwę miasta");

        searchButton = createSearchButton();

        TextArea weatherTextArea = new TextArea();
        weatherTextArea.setEditable(false);
        weatherTextArea.setWrapText(true);
        weatherTextArea.prefWidthProperty().bind(borderPane.widthProperty());
        weatherTextArea.prefHeightProperty().bind(borderPane.heightProperty());

        borderPane.setTop(headerLabel);
        BorderPane.setMargin(headerLabel, new Insets(10, 0, 10, 0));

        borderPane.setCenter(weatherTextArea);
        borderPane.setBottom(vbox);
        BorderPane.setMargin(vbox, new Insets(10, 0, 10, 0));

        vbox.getChildren().addAll(cityTextField, searchButton);

        Scene scene = new Scene(borderPane, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private Button createSearchButton() {
        Button button = new Button();

        button.setMaxHeight(20);
        button.setMaxWidth(50);

        ImageView searchImage = new ImageView(new Image("https://www.iconfinder.com/icons/211817/download/png/32"));
        button.setGraphic(searchImage);

        button.setOnAction(event -> {
            String cityName = cityTextField.getText();
            if (!cityName.isEmpty()) {
                fetchData(cityName);
            } else {
                showAlert("Błąd", "Proszę wpisać nazwę miasta.", Alert.AlertType.ERROR);
            }
        });

        return button;
    }

    private void fetchData(String cityName) {
        try {
            String apiUrl = String.format("%s?q=%s&appid=%s&lang=pl&units=metric", BASE_URL, cityName, API_KEY);

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            InputStream inputStream = connection.getInputStream();
            Scanner scanner = new Scanner(inputStream);
            String jsonText = scanner.useDelimiter("\\A").next();
            scanner.close();

            JSONParser parser = new JSONParser();
            JSONObject jsonData = (JSONObject) parser.parse(jsonText);

            StringBuilder weatherInfo = new StringBuilder();

            JSONArray weatherArray = (JSONArray) jsonData.get("weather");
            JSONObject weatherObject = (JSONObject) weatherArray.get(0);
            String description = (String) weatherObject.get("description");
            String icon = (String) weatherObject.get("icon");
            weatherInfo.append("Pogoda: ").append(description).append("\n");

            Image weatherIconImage = new Image("http://openweathermap.org/img/wn/" + icon + "@2x.png");
            ImageView weatherIcon = new ImageView(weatherIconImage);
            weatherIcon.setFitHeight(80);
            weatherIcon.setFitWidth(100);
            VBox vbox = (VBox) borderPane.getBottom();
            vbox.getChildren().add(weatherIcon);

            JSONObject mainObject = (JSONObject) jsonData.get("main");
            double temperature = (double) mainObject.get("temp");
            double tempMin = (double) mainObject.get("temp_min");
            double tempMax = (double) mainObject.get("temp_max");
            double feelsLike = (double) mainObject.get("feels_like");
            long humidity = (long) mainObject.get("humidity");
            long pressure = (long) mainObject.get("pressure");
            weatherInfo.append("Main Data:\n")
                    .append("Temperatura: ").append(temperature).append("°C\n")
                    .append("Min Temperatura: ").append(tempMin).append("°C\n")
                    .append("Max Temperatura: ").append(tempMax).append("°C\n")
                    .append("Temperatura odczuwalna: ").append(feelsLike).append("°C\n")
                    .append("Wilgotność: ").append(humidity).append("%\n")
                    .append("Ciśnienie: ").append(pressure).append("hPa\n");

            JSONObject windObject = (JSONObject) jsonData.get("wind");
            double windSpeed = (double) windObject.get("speed");
            Long windDeg = (Long) windObject.get("deg");

            // Calculate wind direction
            String[] directionsArray = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            int index = (int) (Math.round((windDeg % 360) / 45.0) % 8);
            index = (index + 8) % 8;  // Ensure index is non-negative
            String windDirection = directionsArray[index];

            weatherInfo.append("Prędkość wiatru: ").append(windSpeed).append(" m/s\n");
            weatherInfo.append("Kierunek wiatru: ").append(windDirection).append("\n");

            long visibility = (long) jsonData.get("visibility");
            weatherInfo.append("Widoczność: ").append(visibility).append("%\n");

            JSONObject rainObject = (JSONObject) jsonData.get("rain");
            if (rainObject != null) {
                weatherInfo.append("Deszcz: ").append(rainObject.toString()).append("\n");
            }

            JSONObject snowObject = (JSONObject) jsonData.get("snow");
            if (snowObject != null) {
                weatherInfo.append("Śnieg: ").append(snowObject.toString()).append("\n");
            }

            JSONObject cloudsObject = (JSONObject) jsonData.get("clouds");
            long cloudiness = (long) cloudsObject.get("all");
            weatherInfo.append("Zachmurzenie: ").append(cloudiness).append("%\n");

            String cityNameValue = (String) jsonData.get("name");
            weatherInfo.append("Miasto: ").append(cityNameValue);

            TextArea weatherTextArea = new TextArea();
            weatherTextArea.setEditable(false);
            weatherTextArea.setWrapText(true);
            weatherTextArea.setText(weatherInfo.toString());
            borderPane.setCenter(weatherTextArea);

            vbox.getChildren().remove(searchButton);
            vbox.getChildren().remove(cityTextField);

            Button exitButton = new Button("Zamknij aplikację");
            exitButton.setOnAction(event -> {
                Stage stage = (Stage) borderPane.getScene().getWindow();
                stage.close();
            });
            vbox.getChildren().add(exitButton);

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Wpisz poprawną nazwę miasta!", Alert.AlertType.ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Błąd podczas przetwarzania danych JSON.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
