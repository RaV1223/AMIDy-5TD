package com.example.asynctask2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class EditProductActivity extends AppCompatActivity {

    private EditText nameEditText, priceEditText, descriptionEditText;
    private String originalName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        nameEditText = findViewById(R.id.nameEditText);
        priceEditText = findViewById(R.id.priceEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        Button saveButton = findViewById(R.id.saveButton);
        Button deleteButton = findViewById(R.id.deleteButton);

        originalName = getIntent().getStringExtra("productName");
        double price = getIntent().getDoubleExtra("productPrice",0);
        String description = getIntent().getStringExtra("productDescription");

        nameEditText.setText(originalName);
        priceEditText.setText(String.valueOf(price));
        descriptionEditText.setText(description);

        saveButton.setOnClickListener(view -> {
            String newName = nameEditText.getText().toString();
            double newPrice = Double.parseDouble(priceEditText.getText().toString());
            String newDescription = descriptionEditText.getText().toString();
            new SaveProductTask().execute(new Product(newName, newPrice, newDescription));
        });

        deleteButton.setOnClickListener(view -> new DeleteProductTask().execute(originalName));
    }

    private class SaveProductTask extends AsyncTask<Product, Void, Void> {
        @Override
        protected Void doInBackground(Product... products) {
            List<Product> currentProducts = loadProductsFromJson();

            // Usunięcie oryginalnego produktu z listy
            for (int i = 0; i < currentProducts.size(); i++) {
                if (currentProducts.get(i).getName().equals(originalName)) {
                    currentProducts.remove(i);
                    break; // Przerwij po usunięciu
                }
            }
            currentProducts.add(products[0]);
            saveProductsToJson(currentProducts);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            Toast.makeText(EditProductActivity.this, "Produkt zapisany", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private class DeleteProductTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... names) {
            List<Product> currentProducts = loadProductsFromJson();

            for (int i = 0; i < currentProducts.size(); i++) {
                if (currentProducts.get(i).getName().equals(names[0])) {
                    currentProducts.remove(i);
                    break;
                }
            }
            saveProductsToJson(currentProducts);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            Toast.makeText(EditProductActivity.this, "Produkt usunięty", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void saveProductsToJson(List<Product> products) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (Product product : products) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("name", product.getName());
                jsonObject.put("price", product.getPrice());
                jsonObject.put("description", product.getDescription());
                jsonArray.put(jsonObject);
            }

            FileOutputStream fos = openFileOutput("products.json", MODE_PRIVATE);
            fos.write(jsonArray.toString().getBytes());
            fos.close();
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    private List<Product> loadProductsFromJson() {
        List<Product> products = new ArrayList<>();
        try {
            InputStream inputStream = openFileInput("products.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder jsonBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonBuilder.append(line);
            }
            JSONArray jsonArray = new JSONArray(jsonBuilder.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String name = jsonObject.getString("name");
                double price = jsonObject.getDouble("price");
                String description = jsonObject.getString("description");
                products.add(new Product(name, price, description));
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return products;
    }
}
