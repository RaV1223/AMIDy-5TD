package com.example.asynctask2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button showAllButton = findViewById(R.id.show_all_button);
        Button addProductButton = findViewById(R.id.add_product_button);

        showAllButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ShowAllProductsActivity.class);
            startActivity(intent);
        });

        addProductButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, EditProductActivity.class);
            startActivity(intent);
        });
    }
}
