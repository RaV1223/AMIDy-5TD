class Klient {
    private String nazwa;
    private int numerId;
    private String adres;

    public Klient(String nazwa, int numerId, String adres) {
        this.nazwa = nazwa;
        this.numerId = numerId;
        this.adres = adres;
    }

    public String getNazwa() {
        return nazwa;
    }

    public int getNumerId() {
        return numerId;
    }

    public String getAdres() {
        return adres;
    }

    public void wyswietlInformacje() {
        System.out.println("Klient: " + nazwa + ", ID: " + numerId + ", Adres: " + adres);
    }
}

class KontoBankowe {
    private String numerKonta;
    private double saldo;
    private Klient wlasciciel;

    public KontoBankowe(String numerKonta, double saldo, Klient wlasciciel) {
        this.numerKonta = numerKonta;
        this.saldo = saldo;
        this.wlasciciel = wlasciciel;
    }

    public String getNumerKonta() {
        return numerKonta;
    }

    public double getSaldo() {
        return saldo;
    }

    public Klient getWlasciciel() {
        return wlasciciel;
    }

    public void wplacSrodki(double kwota) {
        saldo += kwota;
        System.out.println("------------------------------------------");
        System.out.println("Wpłata: " + kwota + " PLN na konto " + numerKonta);
    }

    public void wyplacSrodki(double kwota) {
        if (kwota > saldo) {
            System.out.println("------------------------------------------");
            System.out.println("Brak wystarczających środków na koncie " + numerKonta);
        } else {
            saldo -= kwota;
            System.out.println("------------------------------------------");
            System.out.println("Wypłata: " + kwota + " PLN z konta " + numerKonta);
        }
    }

    public void wyswietlInformacje() {
        System.out.println("------------------------------------------");
        System.out.println("Konto: " + numerKonta + ", Saldo: " + saldo + " PLN");
        wlasciciel.wyswietlInformacje();
    }
}

public class Main {
    public static void main(String[] args) {
        Klient klient1 = new Klient("Andrzej Duda", 1, "ul. Obamańska 12");
        Klient klient2 = new Klient("Karol Wojtyła", 2, "ul. Watykańska 2137");

        KontoBankowe konto1 = new KontoBankowe("123456", 4200.0, klient1);
        KontoBankowe konto2 = new KontoBankowe("654321", 2137.0, klient2);

        klient1.wyswietlInformacje();
        konto1.wyswietlInformacje();

        klient2.wyswietlInformacje();
        konto2.wyswietlInformacje();

        konto1.wplacSrodki(500.0);

        konto2.wyplacSrodki(700.0);

        konto1.wyswietlInformacje();
        konto2.wyswietlInformacje();
    }
}
