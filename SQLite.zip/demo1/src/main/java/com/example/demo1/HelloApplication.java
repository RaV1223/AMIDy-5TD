package com.example.demo1;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.*;

public class HelloApplication extends Application {

    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/baza_amidy";
        String user = "root";
        String password = "";
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    private TableView<String[]> resultTable = new TableView<>();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX i JDBC");

        MenuBar menuBar = new MenuBar();
        Menu menu = new Menu("Opcje");
        MenuItem createTableItem = new MenuItem("Tworzenie tabeli");
        MenuItem addRecordItem = new MenuItem("Dodaj rekordy");
        MenuItem searchRecordItem = new MenuItem("Wyszukaj rekordy");
        MenuItem exitItem = new MenuItem("Wyjście");
        menu.getItems().addAll(createTableItem, addRecordItem, searchRecordItem, new SeparatorMenuItem(), exitItem);
        menuBar.getMenus().add(menu);

        createTableItem.setOnAction(event -> showCreateTableForm());
        addRecordItem.setOnAction(event -> showAddRecordForm());
        searchRecordItem.setOnAction(event -> showSearchRecordForm());
        exitItem.setOnAction(event -> primaryStage.close());

        GridPane root = new GridPane();
        root.setPadding(new Insets(10, 10, 10, 10));
        root.setVgap(8);
        root.setHgap(10);
        root.getChildren().add(menuBar);

        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

    private void showCreateTableForm() {
        Stage createTableStage = new Stage();
        createTableStage.setTitle("Tworzenie tabeli");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.add(new Label("Nazwa tabeli:"), 0, 0);
        TextField tableNameField = new TextField();
        grid.add(tableNameField, 1, 0);

        grid.add(new Label("Kolumny:"), 0, 1);
        TextArea columnsArea = new TextArea();
        columnsArea.setPromptText("Kolumna1 VARCHAR(255) PRIMARY KEY,\nKolumna2 INT AUTO_INCREMENT,\nKolumna3 DATE");
        grid.add(columnsArea, 1, 1);

        Button createTableButton = new Button("Utwórz tabelę");
        grid.add(createTableButton, 1, 2);

        Button backButton = new Button("Powrót");
        grid.add(backButton, 0, 2);

        backButton.setOnAction(event -> createTableStage.close());

        createTableButton.setOnAction(event -> {
            String tableName = tableNameField.getText();
            String columns = columnsArea.getText();
            createTable(tableName, columns);
        });

        Label instructionsLabel = new Label("Format kolumn: Nazwa Typ_Danych [PRIMARY KEY] [AUTO_INCREMENT] ,Kolumna2 INT AUTO_INCREMENT,Kolumna3 DATE");
        Label instructionsLabel2 = new Label("UWAGA! Aby AUTO_INCREMENT zadziałał wpisane muszą być obydwie opcje tzn. PRIMARY KEY oraz AUTO_INCREMENT");
        instructionsLabel.setWrapText(true);
        instructionsLabel2.setWrapText(true);
        grid.add(instructionsLabel, 1, 3);
        grid.add(instructionsLabel2, 1, 4);

        Scene scene = new Scene(grid, 800, 300);
        createTableStage.setScene(scene);
        createTableStage.show();
    }

    private void showAddRecordForm() {
        Stage addRecordStage = new Stage();
        addRecordStage.setTitle("Dodawanie rekordów");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.add(new Label("Nazwa tabeli:"), 0, 0);
        TextField tableNameField = new TextField();
        grid.add(tableNameField, 1, 0);

        grid.add(new Label("Nazwa kolumny:"), 0, 1);
        TextField columnNameField = new TextField();
        grid.add(columnNameField, 1, 1);

        Button addButton = new Button("Dodaj rekord");
        grid.add(addButton, 1, 2);

        Button backButton = new Button("Powrót");
        grid.add(backButton, 0, 2);

        backButton.setOnAction(event -> addRecordStage.close());

        addButton.setOnAction(event -> {
            String tableName = tableNameField.getText();
            String columnName = columnNameField.getText();
            addRecord(tableName, columnName);
        });

        Scene scene = new Scene(grid, 300, 250);
        addRecordStage.setScene(scene);
        addRecordStage.show();
    }

    private void showSearchRecordForm() {
        Stage searchRecordStage = new Stage();
        searchRecordStage.setTitle("Wyszukiwanie rekordów");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.add(new Label("Nazwa tabeli:"), 0, 0);
        TextField tableNameField = new TextField();
        grid.add(tableNameField, 1, 0);

        grid.add(new Label("Nazwa kolumny:"), 0, 1);
        TextField columnNameField = new TextField();
        grid.add(columnNameField, 1, 1);

        grid.add(new Label("Wartość do wyszukania:"), 0, 2);
        TextField searchValueField = new TextField();
        grid.add(searchValueField, 1, 2);

        Button searchButton =  new Button("Wyszukaj");
        grid.add(searchButton, 1, 3);

        Button backButton = new Button("Powrót");
        grid.add(backButton, 0, 3);

        backButton.setOnAction(event -> searchRecordStage.close());

        searchButton.setOnAction(event -> {
            String tableName = tableNameField.getText();
            String columnName = columnNameField.getText();
            String searchValue = searchValueField.getText();
            searchRecord(tableName, columnName, searchValue);
        });

        grid.add(resultTable, 0, 4, 2, 1);

        Scene scene = new Scene(grid, 300, 250);
        searchRecordStage.setScene(scene);
        searchRecordStage.show();
    }

    private void createTable(String tableName, String columns) {
        try (Connection connection = connect()) {
            if (connection != null) {
                Statement statement = connection.createStatement();
                String query = "CREATE TABLE " + tableName + " (" + columns + ")";
                statement.executeUpdate(query);
                connection.close();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Sukces");
                alert.setHeaderText(null);
                alert.setContentText("Pomyślnie utworzono tabelę: " + tableName);
                alert.showAndWait();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Błąd");
            alert.setHeaderText(null);
            alert.setContentText("Wystąpił błąd podczas tworzenia tabeli.");
            alert.showAndWait();
        }
    }

    private void addRecord(String tableName, String columnName) {
        try (Connection connection = connect()) {
            if (connection != null) {
                String query = "INSERT INTO " + tableName + " (" + columnName + ") VALUES (?)";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Dodawanie rekordu");
                dialog.setHeaderText("Dodawanie rekordu do tabeli: " + tableName);
                dialog.setContentText("Wprowadź wartość dla kolumny " + columnName + ":");
                dialog.showAndWait().ifPresent(value -> {
                    try {
                        preparedStatement.setString(1, value);
                        preparedStatement.executeUpdate();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Sukces");
                        alert.setHeaderText(null);
                        alert.setContentText("Pomyślnie dodano rekord do tabeli: " + tableName);
                        alert.showAndWait();
                    } catch (SQLException e) {
                        e.printStackTrace();
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Błąd");
                        alert.setHeaderText(null);
                        alert.setContentText("Wystąpił błąd podczas dodawania rekordu.");
                        alert.showAndWait();
                    }
                });
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Błąd");
            alert.setHeaderText(null);
            alert.setContentText("Wystąpił błąd podczas łączenia z bazą danych.");
            alert.showAndWait();
        }
    }

    private void searchRecord(String tableName, String columnName, String searchValue) {
        try (Connection connection = connect()) {
            if (connection != null) {
                String query = "SELECT * FROM " + tableName + " WHERE " + columnName + " = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, searchValue);
                ResultSet resultSet = preparedStatement.executeQuery();

                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();

                resultTable.getItems().clear();
                resultTable.getColumns().clear();

                for (int i = 1; i <= columnCount; i++) {
                    final int j = i - 1;
                    TableColumn<String[], String> column = new TableColumn<>(metaData.getColumnName(i));
                    column.setCellValueFactory(param -> new SimpleStringProperty(param.getValue()[j]));
                    resultTable.getColumns().add(column);
                }

                while (resultSet.next()) {
                    String[] row = new String[columnCount];
                    for (int i = 1; i <= columnCount; i++) {
                        row[i - 1] = resultSet.getString(i);
                    }
                    resultTable.getItems().add(row);
                }

                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Błąd");
            alert.setHeaderText(null);
            alert.setContentText("Wystąpił błąd podczas wyszukiwania rekordu.");
            alert.showAndWait();
        }
    }



    public static void main(String[] args) {
        launch(args);
    }
}

