import java.util.ArrayList;
import java.util.Scanner;

class Zadanie {
    private String nazwa;
    private String opis;
    private boolean zakonczone;

    public Zadanie(String nazwa, String opis) {
        this.nazwa = nazwa;
        this.opis = opis;
        this.zakonczone = false;
    }

    public String pobierzNazwe() {
        return nazwa;
    }

    public String pobierzOpis() {
        return opis;
    }

    public boolean czyZakonczone() {
        return zakonczone;
    }

    public void oznaczJakoZakonczone() {
        zakonczone = true;
    }
}

public class ToDoList {
    private static ArrayList<Zadanie> zadania = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int wybor;

        do {
            wyswietlMenu();
            wybor = scanner.nextInt();
            scanner.nextLine(); // konsumuj znak nowej linii

            switch (wybor) {
                case 1:
                    dodajZadanie();
                    break;
                case 2:
                    oznaczJakoZakonczone();
                    break;
                case 3:
                    wyswietlZadania();
                    break;
                case 4:
                    usunZadanie();
                    break;
                case 5:
                    System.out.println("Koniec programu. Do zobaczenia!");
                    break;
                default:
                    System.out.println("Nieprawidłowy wybór. Spróbuj ponownie.");
            }
        } while (wybor != 5);
    }

    private static void wyswietlMenu() {
        System.out.println("==== Zarządzanie Zadaniami ====");
        System.out.println("1. Dodaj nowe zadanie");
        System.out.println("2. Oznacz zadanie jako zakończone");
        System.out.println("3. Wyświetl listę zadań");
        System.out.println("4. Usuń zadanie");
        System.out.println("5. Wyjście");
        System.out.print("Wybierz opcję (1/2/3/4/5): ");
    }

    private static void dodajZadanie() {
        System.out.print("Podaj nazwę zadania: ");
        String nazwa = scanner.nextLine();
        System.out.print("Podaj opis zadania: ");
        String opis = scanner.nextLine();

        Zadanie zadanie = new Zadanie(nazwa, opis);
        zadania.add(zadanie);

        System.out.println("Zadanie \"" + nazwa + "\" zostało dodane do listy.");
    }

    private static void oznaczJakoZakonczone() {
        wyswietlZadania();
        System.out.print("Podaj numer zadania do oznaczenia jako zakończone: ");
        int numerZadania = scanner.nextInt();

        if (czyPoprawnyNumerZadania(numerZadania)) {
            Zadanie zadanie = zadania.get(numerZadania - 1);
            zadanie.oznaczJakoZakonczone();
            System.out.println("Zadanie \"" + zadanie.pobierzNazwe() + "\" zostało oznaczone jako zakończone.");
        } else {
            System.out.println("Nieprawidłowy numer zadania.");
        }
    }

    private static void wyswietlZadania() {
        System.out.println("==== Lista Zadań ====");
        if (zadania.isEmpty()) {
            System.out.println("(brak zadań)");
        } else {
            for (int i = 0; i < zadania.size(); i++) {
                Zadanie zadanie = zadania.get(i);
                String status = zadanie.czyZakonczone() ? "[x]" : "[ ]";
                System.out.println((i + 1) + ". " + status + " " + zadanie.pobierzNazwe() + ": " + zadanie.pobierzOpis());
            }
        }
    }

    private static void usunZadanie() {
        wyswietlZadania();
        System.out.print("Podaj numer zadania do usunięcia: ");
        int numerZadania = scanner.nextInt();

        if (czyPoprawnyNumerZadania(numerZadania)) {
            Zadanie usunieteZadanie = zadania.remove(numerZadania - 1);
            System.out.println("Zadanie \"" + usunieteZadanie.pobierzNazwe() + "\" zostało usunięte z listy.");
        } else {
            System.out.println("Nieprawidłowy numer zadania.");
        }
    }

    private static boolean czyPoprawnyNumerZadania(int numerZadania) {
        return numerZadania > 0 && numerZadania <= zadania.size();
    }
}
