package com.example.demo2;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HelloApplication extends Application {
    private RotateTransition rotateTransition;
    private Button stepButton;
    private Button startButton;
    private Button stopButton;

    @Override
    public void start(Stage stage) {
        Line upperLine1 = new Line(200, 100 - 30, 400, 100 - 30);
        Line upperLine2 = new Line(400, 100 - 30, 300, 230 - 30);
        Line upperLine3 = new Line(300, 230 - 30, 200, 100 - 30);

        // Creating lines for the lower triangle with adjusted Y positions
        Line lowerLine1 = new Line(200, 200 - 50, 400, 200 - 50);
        Line lowerLine2 = new Line(400, 200 - 50, 300, 70 - 50);
        Line lowerLine3 = new Line(300, 70 - 50, 200, 200 - 50);

        Color lineColor = Color.BLUE;
        double lineWidth = 2.0;
        upperLine1.setStroke(lineColor);
        upperLine2.setStroke(lineColor);
        upperLine3.setStroke(lineColor);
        lowerLine1.setStroke(lineColor);
        lowerLine2.setStroke(lineColor);
        lowerLine3.setStroke(lineColor);
        upperLine1.setStrokeWidth(lineWidth);
        upperLine2.setStrokeWidth(lineWidth);
        upperLine3.setStrokeWidth(lineWidth);
        lowerLine1.setStrokeWidth(lineWidth);
        lowerLine2.setStrokeWidth(lineWidth);
        lowerLine3.setStrokeWidth(lineWidth);

        Group root = new Group(upperLine1, upperLine2, upperLine3, lowerLine1, lowerLine2, lowerLine3);

        rotateTransition = new RotateTransition(Duration.seconds(3), root);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(Animation.INDEFINITE);
        rotateTransition.setInterpolator(Interpolator.LINEAR);

        startButton = new Button("Start");
        startButton.setOnAction(e -> rotateTransition.play());
        stopButton = new Button("Stop");
        stopButton.setOnAction(e -> rotateTransition.pause());
        stepButton = new Button("Step");
        stepButton.setOnAction(e -> rotateTransition.jumpTo(rotateTransition.getCurrentTime().add(Duration.seconds(0.1))));

        startButton.setLayoutX(10);
        startButton.setLayoutY(10);
        stopButton.setLayoutX(70);
        stopButton.setLayoutY(10);
        stepButton.setLayoutX(130);
        stepButton.setLayoutY(10);

        root.getChildren().addAll(startButton, stopButton, stepButton);
        Scene scene = new Scene(root, 500, 300);
        stage.setTitle("Gwiazda Dawida");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
