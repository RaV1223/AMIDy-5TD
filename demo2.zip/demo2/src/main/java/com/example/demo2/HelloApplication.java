package com.example.demo2;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public class HelloApplication extends Application {
    int x = 3;
    int y = 3;

    public static void main(String[] args) {
        Application.launch(args);
    }
    private void BallAnimation(final Scene scene) {
        Random random = new Random();

        double randomX = random.nextDouble() * (scene.getWidth() - 20);
        double randomY = random.nextDouble() * (scene.getHeight() - 20);

        Circle ball = new Circle(randomX, randomY, 20);
        ball.setFill(Color.RED);

        Group root = (Group) scene.getRoot();
        root.getChildren().add(ball);

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        KeyFrame collision = new KeyFrame(Duration.seconds(.0090),
                (e) -> {
                    double MinX = ball.getBoundsInParent().getMinX();
                    double MinY = ball.getBoundsInParent().getMinY();
                    double xMax = ball.getBoundsInParent().getMaxX();
                    double yMax = ball.getBoundsInParent().getMaxY();

                    if (MinX < 0 || xMax > scene.getWidth()) {
                        x = x * -1;
                    }
                    if (MinY < 0 || yMax > scene.getHeight()) {
                        y = y * -1;
                    }
                    ball.setTranslateX(ball.getTranslateX() + x);
                    ball.setTranslateY(ball.getTranslateY() + y);
                });

        timeline.getKeyFrames().add(collision);
        timeline.play();
    }
    @Override
    public void start(final Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, 800, 600, Color.GREEN);

        primaryStage.setScene(scene);
        primaryStage.show();

        BallAnimation(scene);
    }
}
